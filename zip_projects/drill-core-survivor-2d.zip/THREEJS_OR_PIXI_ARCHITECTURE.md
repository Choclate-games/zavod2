# PixiJS 2D Rendering Architecture: Бур Судного Дня: Шахтерский Рогалик

## 1. Stage Hierarchy
```text
Stage (PIXI.Container)
├── BackgroundLayer (Tiled background)
├── PropsLayer (Obstacles and interactive objects)
├── EntityLayer (Player, Enemies, Weapons sorted by Y-depth)
├── ParticleLayer (PIXI.ParticleContainer for bullet hell and sparks)
└── UILayer (DOM overlay for crisp resolution independence)
```

## 2. Sprite Batching Best Practices
- Single shared sprite atlas via TexturePacker.
- Pre-allocated particle pool of 1000 items in `PIXI.ParticleContainer`.
