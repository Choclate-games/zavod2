# Level & Arena Design: Черепичный Спринт: Чистый Флоу

## 1. Arena Layout & Geometry
- **Floor Material**: High-contrast textured ground with dynamic decals.
- **Perimeter**: Perimeter bounds and boundary collision walls.
- **Hazard Zones**:
  - Central tactical cover.
  - Perimeter traps and dynamic obstacles.

## 2. Environmental Pacing
- **Early Waves**: Clear arena floor, basic enemy groups.
- **Mid Waves**: Hazards activate, armored elite units appear.
- **Climax Waves**: Boss encounter with dynamic arena events.
