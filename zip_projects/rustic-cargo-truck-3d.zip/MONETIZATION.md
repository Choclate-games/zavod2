# Monetization Specification: Лесной Рейс: Доставка на Лесопилку 3D

## 1. Strategy Summary
Мягкая гибридная модель: ненавязчивая межстраничная реклама между рейсами, ценные Rewarded видео (удвоение заработка, спасательный магнит для груза) и покупка эксклюзивных лесовозов/отключения рекламы.

## 2. Rewarded Video Ad Placements
### Удвоить награду за рейс (`double_reward`)
- **Benefit**: Умножает заработанные монеты за доставленный груз на x2
- **Trigger**: Экран завершения рейса на лесопилке
- **Limit**: После каждого успешного заезда

### Магнит груза (Возврат) (`cargo_magnet_revive`)
- **Benefit**: Возвращает все выпавшие брёвна обратно в кузов и чинит целостность до 100%
- **Trigger**: Критическая потеря груза во время заезда
- **Limit**: 1 раз за заезд при потере >50% груза

### Тест-драйв супер-подвески (`free_super_tuning`)
- **Benefit**: Дает максимальный уровень подвески и шин на один следующий рейс
- **Trigger**: Экран гаража перед стартом
- **Limit**: 1 раз в 10 минут


## 3. Interstitial Ads Rules
- Minimum **90 seconds** interval between consecutive interstitials.
- Zero interstitials during active combat gameplay.
- Shown only on run game over or returning to Main Menu.

## 4. Optional In-App Purchases (IAP)
- **Отключение рекламы** (`remove_ads_forever`): Полностью отключает все межстраничные баннеры навсегда (Tier 2 (~199 RUB / 1.99 USD))
- **Тягач 'Таёжный Медведь 6x6'** (`truck_taiga_beast`): Эксклюзивный полноприводный трехосный грузовик с высокими бортами (Tier 3 (~299 RUB / 2.99 USD))
- **Мешок деревенского золота** (`coin_pack_large`): Большой запас монет на полную прокачку любого грузовика (Tier 1 (~99 RUB / 0.99 USD))
